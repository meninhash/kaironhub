# Proyecto Kairon - Bases de datos Alpha 0.1

Este paquete contiene la estructura inicial para las bases de datos de la versión Alpha 0.1 del Proyecto Kairon.

## PostgreSQL (Prisma)
- User
- Session
- Reputation
- PaymentLog
- TaskAssignment

## MongoDB (Mongoose)
- Robot
- Task
- EventLog
- AuditTrail

### Instrucciones completas en la guía paso a paso incluida.
