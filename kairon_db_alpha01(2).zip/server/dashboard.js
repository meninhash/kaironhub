const express = require('express');
const mongoose = require('mongoose');
const { PrismaClient } = require('@prisma/client');
const Robot = require('../models/robot.model');
const Task = require('../models/task.model');

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3000;

app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/postgres/users', async (req, res) => {
  const users = await prisma.user.findMany({
    include: { reputations: true, payments: true }
  });
  res.json(users);
});

app.get('/mongo/robots', async (req, res) => {
  const robots = await Robot.find();
  res.json(robots);
});

app.get('/mongo/tasks', async (req, res) => {
  const tasks = await Task.find();
  res.json(tasks);
});

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  app.listen(PORT, () => {
    console.log(`Dashboard running at http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error("MongoDB connection error:", err);
});
