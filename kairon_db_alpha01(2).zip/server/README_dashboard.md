# Dashboard Web - Proyecto Kairon Alpha 0.1

Este dashboard proporciona una interfaz visual para consultar los datos de PostgreSQL y MongoDB usados en la versión Alpha 0.1 del Proyecto Kairon.

## Rutas disponibles

- `/` — Panel visual con botones.
- `/postgres/users` — Lista de usuarios con reputación y pagos.
- `/mongo/robots` — Lista de robots registrados.
- `/mongo/tasks` — Lista de tareas.

## Ejecución manual

1. Instalar dependencias:
   ```bash
   npm install express mongoose @prisma/client
   ```

2. Lanzar el servidor:
   ```bash
   node server/dashboard.js
   ```

3. Acceder desde el navegador a:
   ```
   http://localhost:3000
   ```

## Ejecución con Docker

El dashboard se incluye como servicio en `docker-compose.yml`. Para levantar todo el entorno con bases de datos y dashboard:

```bash
docker compose -f docker/docker-compose.yml up --build
```

El panel estará disponible en `http://localhost:3000`.

