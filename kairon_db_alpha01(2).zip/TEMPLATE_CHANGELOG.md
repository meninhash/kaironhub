# Changelog - Proyecto Kairon

## Versión [Nombre de la versión]  
**Fecha:** [dd-mm-aaaa]  
**Estado:** [EN PROGRESO / COMPLETADO / TESTING]

---

### Funcionalidades implementadas:

#### [Módulo o componente]
- [Descripción de funcionalidad 1]
- [Descripción de funcionalidad 2]

#### [Otro módulo]
- [Descripción de funcionalidad]

---

### Archivos clave:

- [ruta/al/archivo1]
- [ruta/al/archivo2]
- [carpeta/*.formato]

---

### Observaciones:

- [Observación general del progreso, dependencias o decisiones técnicas importantes]
- [Riesgos o tareas pendientes]
