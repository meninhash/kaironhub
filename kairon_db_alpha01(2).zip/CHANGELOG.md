# Changelog - Proyecto Kairon

## Versión Alpha 0.1 (BBDD)

**Fecha:** 28-29 marzo 2025  
**Estado:** COMPLETADO

---

### Funcionalidades implementadas:

#### Bases de datos:

- Diseño conceptual y modelo entidad-relación para PostgreSQL y MongoDB.
- Esquemas completos en Prisma (PostgreSQL) y Mongoose (MongoDB).
- Configuración de `.env.example` para ambas conexiones.

#### Seeds automáticos:

- Script `seed-prisma.ts` para insertar usuario, reputación y pagos.
- Script `seed-mongoose.js` para insertar robots y tareas iniciales.
- Integración total en `docker-compose.yml` con servicios dedicados para seeds.

#### Verificación:

- Script `verify-prisma.ts` para validar datos de usuarios y relaciones.
- Script `verify-mongoose.js` para validar robots y tareas.

#### Dashboard:

- API REST básica con Express y endpoints para PostgreSQL y MongoDB.
- Interfaz visual con botones para cargar datos desde el navegador.
- Dockerfile dedicado para el dashboard integrado en el `docker-compose`.

---

### Archivos clave:

- `prisma/schema.prisma`
- `models/*.js` (Mongoose)
- `scripts/seed-*.ts/js`
- `scripts/verify-*.ts/js`
- `server/dashboard.js`, `index.html`
- `docker/seed-*.Dockerfile`
- `docker/docker-compose.yml`

---

### Observaciones:

- Entorno validado funcionalmente para desarrollo local y VPS.
- Base sólida para extender hacia módulos de gobernanza, IA y reputación Web3.
- Preparado para migración a producción o CI/CD con mínima modificación.

