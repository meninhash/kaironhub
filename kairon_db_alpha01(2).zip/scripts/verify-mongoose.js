const mongoose = require('mongoose');
const Robot = require('../models/robot.model');
const Task = require('../models/task.model');

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  const robots = await Robot.find();
  const tasks = await Task.find();

  console.log("Robots:", robots);
  console.log("Tasks:", tasks);

  process.exit(0);
}).catch(error => {
  console.error(error);
  process.exit(1);
});
