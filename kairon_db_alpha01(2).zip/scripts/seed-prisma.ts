import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const user = await prisma.user.create({
    data: {
      wallet: '0x1234567890abcdef',
      name: 'Alice'
    }
  });

  await prisma.reputation.create({
    data: {
      userId: user.id,
      score: 100
    }
  });

  await prisma.paymentLog.create({
    data: {
      userId: user.id,
      amount: 1.5,
      txHash: '0xabcdefabcdef'
    }
  });

  console.log('Seed completed');
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
