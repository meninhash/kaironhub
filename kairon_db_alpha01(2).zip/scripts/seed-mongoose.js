const mongoose = require('mongoose');
const Robot = require('../models/robot.model');
const Task = require('../models/task.model');

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  await Robot.create({
    name: 'RoboAlpha',
    capabilities: ['welding', 'painting'],
    status: 'available'
  });

  await Task.create({
    title: 'Paint wall',
    description: 'Paint the north wall blue.',
    requiredCapabilities: ['painting']
  });

  console.log('MongoDB seed completed');
  process.exit(0);
}).catch(error => {
  console.error(error);
  process.exit(1);
});
