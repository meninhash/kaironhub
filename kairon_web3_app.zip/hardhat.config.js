// Configuración de red Sepolia + EVM XRP (comentada)
