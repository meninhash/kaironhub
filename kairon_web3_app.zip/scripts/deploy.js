// Script de despliegue para RobotRegistry
