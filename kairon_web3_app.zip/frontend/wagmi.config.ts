// Configuración wagmi con red Sepolia y XRP comentada
