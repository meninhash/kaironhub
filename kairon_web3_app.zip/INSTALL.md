# Manual de instalación - Kairon Web3 Base

## 1. Requisitos
- Node.js >= 18
- pnpm
- MetaMask
- Cuenta testnet Sepolia (Infura)

## 2. Instalación

```bash
pnpm install
cd frontend
pnpm install
```

## 3. Despliegue contrato

```bash
npx hardhat run scripts/deploy.js --network sepolia
```

## 4. Levantar frontend

```bash
pnpm run dev
```

## 5. Redes

- Sepolia: activa por defecto
- XRP EVM: incluida y comentada para activación futura
