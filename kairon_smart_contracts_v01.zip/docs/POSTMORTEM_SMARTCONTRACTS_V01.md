# Postmortem

Resumen de decisiones, tiempos y recomendaciones.